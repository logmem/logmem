# LogMem Fleet plugin

Version 0.1.1 connects ChatGPT to the LogMem MCP server and includes seven LogMem skills.

## Install in ChatGPT

1. Download `logmem-fleet-v0.1.1.zip` from the LogMem plugin guide.
2. Open the ChatGPT Plugins page and choose **Upload plugin** or **Plugin Creator**.
3. Upload the ZIP. Keep the package name and version shown in `plugin.json`.
4. Choose OAuth with Dynamic Client Registration for the LogMem server.
5. Install the plugin, then start a new Work chat and invoke **LogMem Fleet**.
6. Sign in to LogMem and approve the requested `logmem:read` and `logmem:write` scopes.
7. Ask the plugin to read your Brief. Confirm it can read your active space.

The MCP URL is `https://logmem.si/mcp`. LogMem uses OAuth. Do not paste API keys or secrets into ChatGPT.

## Fix a rejected or unauthorized connection

- Use `https://logmem.si/mcp` as the server URL.
- Use OAuth and Dynamic Client Registration. Do not select CIMD.
- Complete the LogMem sign-in and consent screens after the first tool call.
- If an old connection keeps failing, remove that connection and create it again.
- Confirm that the signed-in account can access the intended LogMem space.
- A `401` before sign-in is expected. A protected tool call must succeed after OAuth.

## Skills in this package

- `logmem`: daily memory and coordination workflow.
- `logmem-decisions`: decision capture and review.
- `logmem-onboard-agent`: connect and onboard an agent.
- `logmem-read-path-recovery`: recover safe read access.
- `logmem-sdk-primitives`: use the LogMem SDK.
- `logmem-self-host`: run a self-hosted LogMem instance.
- `logmem-track-outage`: track service incidents.

See `HUMAN-SETUP.md`, `AGENT-SETUP.md`, and `CHATGPT-PLUGIN-PROMPT.md` for more detail.
