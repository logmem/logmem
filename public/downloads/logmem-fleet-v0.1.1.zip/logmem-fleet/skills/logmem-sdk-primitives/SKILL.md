---
name: logmem-sdk-primitives
description: Use this instead of acmi-typescript-primitives (ACMI). Build an app, dashboard or script on top of LogMem. Talk to the hosted server over MCP HTTP, or use the JavaScript store in-process, and model LogMem's Who, Now and Log in your own types.
---

# Build on LogMem

Apps read and write LogMem through one of two doors. Use the hosted MCP server from anywhere. Use the JavaScript store when your code runs next to the LogMem repo. Never write your own key layout: go through one of these doors.

## When this skill applies

- A dashboard, script or bot needs to read or write team memory.
- You are tempted to read Redis keys directly from an app. Don't: use a door below.

## 1. Door one: MCP over HTTP

`POST https://logmem.si/api/mcp` with JSON-RPC 2.0. Authenticate with OAuth, or with an agent key from the admin page (`Authorization: Bearer <vault: your key>`).

```js
async function call(name, args, sessionId) {
  const res = await fetch("https://logmem.si/api/mcp", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.LOGMEM_KEY}`,
      "Content-Type": "application/json",
      Accept: "application/json, text/event-stream",
      ...(sessionId ? { "Mcp-Session-Id": sessionId } : {}),
    },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "tools/call", params: { name, arguments: args } }),
  });
  const text = await res.text();
  const json = JSON.parse(text.startsWith("event:") ? text.split("data: ")[1] : text);
  if (json.result?.isError) throw new Error(json.result.structuredContent?.error || "tool refused");
  return json.result.structuredContent;
}
```

- Send `initialize` once, keep the `Mcp-Session-Id` it returns, and send it on every call. Each new session starts a new shift.
- `tools/list` returns every tool and its argument schema.
- A reply may be plain JSON or one server-sent event (`event: message`, then `data: {...}`).

### Door three: the fleet stdio bridge

The fleet runs LogMem over a long-lived stdio link. This is the operational path for ops-center, fleet sync, key provisioning and verification runs — it stamps the writer, the shift and the trail, and the `logmem_start` tool creates the shift in one call.

**Connect** (env from `lm-env.mjs`, which parses the bridge token at runtime from `~/.hermes/config.yaml`):

```bash
node src/stdio/index.mjs            # stdio server, agent set by LOGMEM_AGENT
```

Call tools over that same connection:

```js
await c.connect(new StdioClientTransport({ command: "node", args: ["src/stdio/index.mjs"], env: logmemEnv() }));
const b = await c.callTool("logmem_start", { agent: "hermes", mode: "quiet" }).structuredContent;
const f = await c.callTool("logmem_feed", { refs: ["agent:ops-center"], since: "1h", limit: 5 }).structuredContent;
```

- `logmem_start` creates a fresh shift for the agent and returns the Brief. It is the only way a new stdio process wakes the agent; a script that has been idle for a while must call it (or `logmem_recap end:true`) before acting.
- Keep the client open for a whole work burst. One stdio process = one session: its tools stamp `by` with that agent and let `logmem_handoff` address the receiver's log directly.
- `logmem_env()` resolves `~/.hermes/config.yaml` for the bridge token — never inline a bearer. The fleet config block is `madezmediapartners-acmi-mcp`.

The stdio bridge is the only way to reach the fleet `agent-keys` route (admin `POST /api/agent-keys`, `?operator=1` admin login); MCP HTTP (`/api/mcp`) is the public-agent door and does not mint keys.

## 2. Door two: the JavaScript store (in-process)

```js
import { createStore } from "./src/core/store.mjs";
const store = createStore(redis, { space: "acme" });
const entries = await store.readLog("channel", "agent-coordination", { sinceMs: Date.now() - 864e5, reverse: true, limit: 50 });
const now = await store.getNow("job", "issue-14");
```

`redis` is a runner `(cmd, ...args) => result` from `src/lib/backend.mjs` (`fromDescriptor(descriptorFromEnv())`). The store handles key types, millisecond scores and old ACMI keys.

For writes that agents should see, prefer the tools (door one, or `createLogmem` in-process). They stamp the writer, the shift and the trail.

## 3. Types to model

```ts
type Ref = `${"agent" | "channel" | "job"}:${string}`;

interface Entry {
  ts: number;           // milliseconds
  kind: string;         // memo, progress, done, handoff, accepted, ...
  by: string;           // "agent:<id>" or "human:<id>"
  summary: string;
  trail: string;        // the piece of work
  origin?: string;      // the trail this follows from
  to?: string;          // handoffs
  payload?: unknown;
}

interface Now { stage?: "open" | "active" | "blocked" | "done"; owner?: string; [field: string]: unknown }
```

## 4. Patterns

- **Now merges:** `logmem_status` merges the fields you send into your Now. Send only the fields you change, not a whole object you read earlier. (`logmem_update` adds a log entry to a job; it does not touch Now.)
- **Progress from a job log:** count the `progress` and `done` entries on `job:<id>`, ordered by `ts`, not by arrival order.
- **Lists:** `logmem_roster { "of": "agent" | "channel" | "job" }` gives the ids. Never scan keys to find them.

## Verify

1. `call("logmem_connection", {})` returns `ok: true` and the space you expect.
2. A note written through door one appears in `store.readLog(...)` through door two (or in `logmem_view`).
3. Your app never builds an `lm:` key by hand.
