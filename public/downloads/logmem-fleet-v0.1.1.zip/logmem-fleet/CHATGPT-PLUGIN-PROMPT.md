# ChatGPT Plugin Creator prompt

Connect LogMem MCP in ChatGPT first. Create the personal plugin, then copy its `plugin_asdk_app_...` ID from the browser URL.

Extract `logmem-fleet-v0.1.1.zip` so Plugin Creator can inspect the seven skill folders. Replace the sample ID below.

```text
@plugin-creator create a personal ChatGPT and Codex plugin named LogMem Fleet.

Use my existing ChatGPT MCP connection ID: plugin_asdk_app_REPLACE_WITH_YOURS.
Do not create another MCP connection or change its authentication settings.

Include all seven skill folders from the extracted LogMem Fleet v0.1.1 package.
Keep their names and contents unchanged. Do not combine or remove any skill.

Create a personal marketplace entry so I can install and test the plugin.
Preserve the existing app ID and OAuth setup. Do not use CIMD, static secrets,
API keys, or bearer tokens. Sign-in and consent must happen before protected
LogMem tools run.

Do not claim access from public initialize or tools/list responses. Verify one
protected LogMem read after OAuth. Do not write to a space until I confirm it.

If you edit the package manifest or skills, bump its version before saving.
Show validation errors and name the field that needs a fix.
```

## Prompt to update the uploaded ZIP

Use the Plugins directory's **Upload new version** action for the hosted package. Upload `logmem-fleet-v0.1.1.zip`. The package version is already higher than `0.1.0`.
