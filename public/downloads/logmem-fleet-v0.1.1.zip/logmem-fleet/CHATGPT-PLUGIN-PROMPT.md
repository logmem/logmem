# ChatGPT Plugin Creator prompt

Upload `logmem-fleet-v0.1.1.zip` with this prompt:

```text
Create a ChatGPT and Codex plugin from the attached LogMem Fleet ZIP.

Keep all seven bundled LogMem skills. Do not remove, rename, or combine them.
Keep the plugin name LogMem Fleet. Keep version 0.1.1 for this upload.

Connect the remote MCP server at https://logmem.si/mcp using Streamable HTTP.
Use OAuth with Dynamic Client Registration. Request logmem:read and logmem:write.
Do not configure CIMD. LogMem does not advertise CIMD support.
Do not use a static client secret, API key, or bearer token.

Use OAuth discovery metadata from the server. The authorization server issuer is
https://logmem.si. Complete browser sign-in and user consent before protected
tool calls. Do not treat a public initialize or tools/list response as proof of
authorized access.

Preserve the bundled plugin manifest and MCP configuration unless validation
requires a correction. If you change plugin metadata or skills, bump the plugin
version before saving. Show any validation errors and the exact field to fix.

After creation, tell me how to install the plugin in ChatGPT and Codex. Then
verify one protected LogMem read after OAuth. Do not write to a space until I
confirm the space and approve the action.
```
