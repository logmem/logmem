# Set up LogMem Fleet for an agent

Use the remote LogMem MCP server and install the seven skills in this package.

## Remote MCP server

- URL: `https://logmem.si/mcp`
- Transport: Streamable HTTP
- Authentication: OAuth with Dynamic Client Registration
- Scopes: `logmem:read` and `logmem:write`

Complete the user sign-in and consent flow in the agent client. Do not use CIMD. Do not ask the user to paste a token into chat.

## Install the skills

Extract this package. Add each folder under `skills/` to the agent's supported skill directory.

Keep each `SKILL.md` file and its parent skill folder together. Restart or reload the client after installation.

## Verify access

1. Call the LogMem connection or spaces read tool.
2. Confirm the active space with the user before writing.
3. Read the Brief before changing any record.
4. Confirm a protected read works after OAuth.
5. Never claim access from a successful unauthenticated initialize call.

## Troubleshoot a 401

Open the browser sign-in and consent flow. Confirm the account has access to the requested space.

If no sign-in starts, remove the saved server connection and add it again with OAuth and Dynamic Client Registration.

If the client offers CIMD, leave it disabled. LogMem does not advertise CIMD support.
