# Set up LogMem Fleet in ChatGPT

Use the plugin ZIP to add LogMem skills and connect the LogMem MCP server.

## Steps

1. Download the current `logmem-fleet-v0.1.1.zip` from the LogMem plugin guide.
2. Open ChatGPT on the web. Open **Plugins** and choose **Upload plugin** or **Plugin Creator**.
3. Upload the ZIP and review the plugin name and version.
4. Set the server URL to `https://logmem.si/mcp`.
5. Choose OAuth with Dynamic Client Registration.
6. Do not choose CIMD. LogMem does not advertise CIMD support.
7. Save the plugin and install it in your personal or workspace plugin directory.
8. Start a new Work chat and invoke **LogMem Fleet**.
9. Sign in at LogMem. Approve the requested scopes for your account.
10. Ask LogMem Fleet to read your Brief and list the active space.

## If ChatGPT says the MCP server denied access

Complete the browser sign-in and consent flow first. Then retry the protected tool call.

If you do not see a LogMem sign-in page, remove the old connection. Add it again with OAuth and Dynamic Client Registration.

An unauthenticated `initialize` request can succeed while a protected tool returns `401`. This is expected before sign-in.

Do not share access tokens, client secrets, or API keys in chat. LogMem uses OAuth for this package.

For a custom MCP connection without the ZIP, add `https://logmem.si/mcp` in ChatGPT Plugins. Choose OAuth, then complete sign-in and consent.
