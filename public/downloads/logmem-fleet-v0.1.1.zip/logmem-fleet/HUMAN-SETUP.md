# Set up LogMem Fleet in ChatGPT

Choose one path. The ZIP path updates a packaged plugin. The personal path helps you test a custom MCP connection.

## Upload the plugin ZIP

1. Download `logmem-fleet-v0.1.1.zip` from the LogMem plugin guide.
2. Open the ChatGPT Plugins directory. Choose **Upload new or existing plugin**.
3. Choose **Upload plugin**. Select the ZIP and review its findings.
4. If ChatGPT asks for a new version, use this ZIP. Its manifest version is `0.1.1`.
5. Open the plugin's MCP settings. Confirm the URL is `https://logmem.si/mcp`.
6. Choose OAuth with Dynamic Client Registration. Do not choose CIMD.
7. Connect the server, sign in to LogMem, and approve the requested scopes.
8. Install the plugin. Start a new chat and read your LogMem Brief.

## Create a personal plugin with Plugin Creator

1. In ChatGPT on the web, add `https://logmem.si/mcp` as a custom MCP server.
2. Choose OAuth with Dynamic Client Registration, then finish sign-in and consent.
3. Create the plugin. Copy its `plugin_asdk_app_...` ID from the browser URL.
4. Download and extract the ZIP. Keep all seven skill folders together.
5. In a ChatGPT Work chat, use the prompt in `CHATGPT-PLUGIN-PROMPT.md`.
6. Replace the sample app ID with your own ID. Keep the existing server connection.
7. Install the local plugin and run one protected LogMem read.

## If ChatGPT says the MCP server denied access

Complete the browser sign-in and consent flow first. Then retry the protected tool call.

If you do not see a LogMem sign-in page, remove the old connection. Add it again with OAuth and Dynamic Client Registration.

An unauthenticated `initialize` request can succeed while a protected tool returns `401`. This is expected before sign-in.

Do not share access tokens, client secrets, or API keys in chat. LogMem uses OAuth for this package.

For a custom MCP connection without the ZIP, add `https://logmem.si/mcp` in ChatGPT Plugins. Choose OAuth, then complete sign-in and consent.
